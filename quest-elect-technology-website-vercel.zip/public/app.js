const menuButton = document.querySelector(".menu-toggle");
const nav = document.querySelector(".nav");
menuButton.addEventListener("click", () => {
  const open = nav.classList.toggle("open");
  menuButton.setAttribute("aria-expanded", String(open));
});
nav.querySelectorAll("a").forEach(a => a.addEventListener("click", () => nav.classList.remove("open")));
document.getElementById("year").textContent = new Date().getFullYear();
const dateInput = document.getElementById("appointmentDate");
dateInput.min = new Date(Date.now() - new Date().getTimezoneOffset() * 60000).toISOString().slice(0,10);
document.querySelectorAll("[data-service]").forEach(link => link.addEventListener("click", () => {
  const form = link.getAttribute("href") === "#appointment" ? document.getElementById("appointmentForm") : document.getElementById("quoteForm");
  const select = form.querySelector('[name="service"]');
  if (select) [...select.options].forEach(o => { if (o.text.toLowerCase() === link.dataset.service.toLowerCase()) select.value = o.value; });
}));
function submitToWhatsApp(form) {
  const message = form.querySelector(".form-message");
  const data = new FormData(form);
  const lines = ["Hello Quest Elect Technology,", "", `Request type: ${data.get("formType")}`, `Name: ${data.get("name")}`, `Phone: ${data.get("phone")}`, `Email: ${data.get("email")}`, `Service: ${data.get("service")}`, `Location: ${data.get("location")}`];
  if (data.get("date")) lines.push(`Preferred date: ${data.get("date")}`);
  if (data.get("time")) lines.push(`Preferred time: ${data.get("time")}`);
  if (data.get("details")) lines.push(`Details: ${data.get("details")}`);
  const url = `https://wa.me/2347086208333?text=${encodeURIComponent(lines.join("\n"))}`;
  message.className = "form-message success";
  message.textContent = "WhatsApp is opening with your request. Please press Send in WhatsApp to submit it.";
  window.open(url, "_blank", "noopener,noreferrer");
}
["quoteForm", "appointmentForm"].forEach(id => document.getElementById(id).addEventListener("submit", event => {
  event.preventDefault();
  if (event.currentTarget.reportValidity()) submitToWhatsApp(event.currentTarget);
}));
