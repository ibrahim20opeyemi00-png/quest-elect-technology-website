# Quest Elect Technology Website

Company website for Quest Elect Technology — *Where innovation meets expertise*.

## Deploy on Vercel
1. Push the contents of this folder to the GitHub repository.
2. In Vercel, choose **Add New → Project** and import `quest-elect-technology-website`.
3. Leave the framework preset as **Other**. The included `vercel.json` sets `public` as the output directory.
4. Click **Deploy**.

## Enquiry forms
The quote and appointment forms open WhatsApp with the customer's details pre-filled. The customer must press **Send** in WhatsApp to submit the enquiry. Email and phone links are also provided in the contact section.

## Company details
- Location: Lagos, Nigeria
- Phone / WhatsApp: +234 7086 208333
- Email: quest_elect_tehnologies@outlook.com

The email address is reproduced exactly as supplied.
